//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Igrf.RC
//
#define IDR_MAINFRAME                   2
#define IDS_CANNOT_OPEN_FILE            3
#define IDR_IGRFTYPE                    6
#define IDR_IGRFEDIT                    7
#define IDD_ABOUTBOX                    100
#define IDI_ICON1                       102
#define IDD_SPLASH                      105
#define IDD_PROFILE_DATE                106
#define IDD_PROFILE_LAT                 107
#define IDB_CEMPBITMAP                  107
#define IDD_PROFILE_LONG                108
#define IDD_PROFILE_HEIGHT              109
#define IDI_HORSE                       114
#define IDC_START                       123
#define IDC_END                         124
#define IDC_N                           125
#define IDC_LAT                         126
#define IDC_LONG                        127
#define IDC_HEIGHT                      128
#define IDC_PYEAR                       132
#define IDC_MODEL                       133
#define IDC_SMODEL                      134
#define IDC_YEARRANGE                   135
#define IDC_BIGICON                     1008
#define IDC_HORSEICON                   1009
#define ID_PROFILE_OF                   32768
#define ID_IGRFPROFILE_OFLONGITUDE      32769
#define ID_IGRFPROFILE_OFHEIGHT         32770
#define ID_IGRFPROFILE_OFYEARS          32771
#define ID_PROFILE_OFLATITUDE           32772
#define IDS_ERRYEAR                     61216
#define IDS_ERRHEIGHT                   61217
#define IDS_ERRLAT                      61218
#define IDS_ERRLONGITUDE                61219
#define IDS_ERR_NOIGRFIP                61221
#define IDS_ERR_IPFEWLINES              61222
#define IDS_ERR_IPNOMODEL               61223
#define IDS_ERR_IPFEWFILES              61224
#define IDS_ERR_IPTOMANYFILES           61225
#define IDS_ERR_BADYEARFORMAT           61226
#define IDS_ERR_BADYEARS                61227
#define IDS_ERR_IPBADNUMFILES           61228

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         136
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
