//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IGRFGEN.RC
//
#define IDD_IGRFDLG                     101
#define IDC_YEAR                        103
#define IDC_MONTH                       104
#define IDC_ALTITUDE                    105
#define IDC_LATDEG                      106
#define IDC_LATMIN                      107
#define IDC_LONGDEG                     108
#define IDC_LONGMIN                     109
#define IDC_TOTAL                       110
#define IDC_DEC                         111
#define IDC_X                           113
#define IDC_Y                           114
#define IDC_Z                           115
#define IDC_INC                         116
#define ID_IGRF_HELP                    122
#define IDC_NORTH                       1001
#define IDC_SOUTH                       1002
#define IDC_EAST                        1003
#define IDC_WEST                        1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
